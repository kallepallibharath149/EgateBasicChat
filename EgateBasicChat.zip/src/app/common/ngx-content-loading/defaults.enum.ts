export enum Defaults {
    PrimaryColor = '#f3f3f3',
    SecondaryColor = '#ecebeb',
    PreserveAspectRatio = 'xMidYMid meet',
    Classes = '',
    Speed = '1000ms',
    Width = '400',
    Height = '130',
    Rx = '0',
    Ry = '1'
}
