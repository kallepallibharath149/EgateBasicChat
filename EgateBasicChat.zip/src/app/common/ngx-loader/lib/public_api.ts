/*
 * Public API Surface of ngx-loading
 */

export * from './ngx-loading.service';
export * from './ngx-loading.component';
export * from './ngx-loading.module';
export * from './ngx-loading-config';
