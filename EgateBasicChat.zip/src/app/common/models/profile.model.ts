export interface IprofileDetails {
    profileId?: string;
    name: string;
    profileImageUrl?: string;
    profileCoverImageUrl?: string;
    value: IprofileId;
}

export interface IprofileId {
id?: any;
}