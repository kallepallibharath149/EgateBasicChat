import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-redirect-togroups',
  templateUrl: './redirect-togroups.component.html',
  styleUrls: ['./redirect-togroups.component.less']
})
export class RedirectTogroupsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  
  }

}
